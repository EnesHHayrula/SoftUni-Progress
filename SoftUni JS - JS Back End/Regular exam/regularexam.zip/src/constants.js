const CONFIG = {
  PORT: 3000,
  DB_URL: "mongodb://127.0.0.1:27017/second-hand-electronics",
  SECRET: "48fd5960-c2b5-42fe-9bf0-bb09bfb8d930",
};

module.exports = CONFIG;
